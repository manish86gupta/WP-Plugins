<?php
if (!defined('ABSPATH')) exit;

class Qoyod_API {

    private $base_url = 'https://api.qoyod.com/2.0/';
    private $sales_account_code = '4101';

    private function request($endpoint, $method = 'POST', $body = null, &$error_output = '') {

        if (!defined('QOYOD_API_KEY') || empty(QOYOD_API_KEY)) {
            $error_output = 'API Key missing in wp-config.php';
            return false;
        }

        $clean_endpoint = ltrim($endpoint, '/');
        $full_url = rtrim($this->base_url, '/') . '/' . $clean_endpoint;

        $args = [
            'method'  => $method,
            'timeout' => 25,
            'headers' => [
                'API-KEY'      => QOYOD_API_KEY,
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ],
        ];

        if ($body !== null) {
            $args['body'] = wp_json_encode($body);
        }

        error_log('QOYOD URL: ' . $full_url);

        if ($body !== null) {
            error_log('QOYOD PAYLOAD: ' . wp_json_encode($body, JSON_PRETTY_PRINT));
        }

        $response = wp_remote_request($full_url, $args);

        if (is_wp_error($response)) {
            $error_output = $response->get_error_message();
            return false;
        }

        $status = wp_remote_retrieve_response_code($response);
        $raw    = wp_remote_retrieve_body($response);

        error_log('QOYOD RESPONSE: ' . $raw);

        $data = json_decode($raw, true);

        if ($status < 200 || $status >= 300) {
            $error_output = $raw ?: 'Unknown API error';
            return false;
        }

        return $data;
    }

    public function get_customer_by_email($email) {
        if (empty($email)) return false;

        $res = $this->request('customers?q[email_eq]=' . urlencode($email), 'GET');

        return $res['customers'][0]['id'] ?? false;
    }

    public function get_customer_by_name($name) {
        if (empty($name)) return false;

        $res = $this->request('customers?q[name_cont]=' . urlencode($name), 'GET');

        return $res['customers'][0]['id'] ?? false;
    }

    public function get_product_by_name($name) {
        if (empty($name)) return false;

        $res = $this->request('products?q[name_en_or_name_ar_cont]=' . urlencode($name), 'GET');

        return $res['products'][0]['id'] ?? false;
    }

    public function create_product_in_qoyod($name, $price) {

        $payload = [
            "product" => [
                "name_en" => $name,
                "name_ar" => $name,
                "sku"     => 'WC-' . sanitize_title($name),
                "buying_price"  => "0.00",
                "selling_price" => (string) round($price, 2),
                "sales_account_id" => $this->sales_account_code,
                "is_active" => true
            ]
        ];

        $res = $this->request('products', 'POST', $payload);

        return $res['product']['id'] ?? false;
    }

    public function create_or_update_customer($order, &$error_output) {

        $email = $order->get_billing_email();
        if (empty($email)) {
            $email = "guest_" . $order->get_id() . "@local.invalid";
        }

        $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());

        if ($customer_name === '') {
            $customer_name = $order->get_billing_company();
        }

        if ($customer_name === '') {
            $customer_name = $email;
        }

        if ($customer_name === '') {
            $customer_name = 'WooCommerce Customer';
        }

        $phone = preg_replace('/[^\d+]/', '', $order->get_billing_phone());
        if (empty($phone)) {
            $phone = "0500000000";
        }

        $payload = [
            "customer" => [
                "name"         => $customer_name,
                "contact_name" => $customer_name,
                "email"        => $email,
                "phone"        => $phone,
                "organization" => "WooCommerce Store",
                "status"       => "Active"
            ]
        ];

        $existing = $this->get_customer_by_email($email);

        if ($existing) {
            $this->request("customers/{$existing}", 'PUT', $payload, $error_output);
            return (int) $existing;
        }

        $res = $this->request('customers', 'POST', $payload, $error_output);

        return $res['customer']['id'] ?? false;
    }

    public function create_invoice_with_items($client_id, $order, &$error_output) {

    if (!$client_id) {
        $client_id = $this->get_customer_by_name("WooCommerce Customer");
    }

    if (!$client_id) {
        $error_output = "Missing customer";
        return false;
    }

    /**
     * IMPORTANT: set your real inventory ID here
     * Example: $inventory_id = 12;
     */
    $inventory_id = 12;

    if (!$inventory_id) {
        $error_output = "Missing inventory_id (required by Qoyod)";
        return false;
    }

    $first = $order->get_billing_first_name();
    $last  = $order->get_billing_last_name();

    $customer_name = trim($first . ' ' . $last);

    if ($customer_name === '') {
        $customer_name = $order->get_billing_email();
    }

    if ($customer_name === '') {
        $customer_name = "WooCommerce Customer";
    }

    $line_items = [];

    foreach ($order->get_items() as $item) {

        $qty = (int) $item->get_quantity();
        if ($qty <= 0) continue;

        $name = $item->get_name();

        $total = (float) $item->get_total();
        $unit_price = $qty > 0 ? round($total / $qty, 2) : 0;
        $tax_amount = round($total * 0.15, 2);

        $product_id = $this->get_product_by_name($name);

        if (!$product_id) {
            $product_id = $this->create_product_in_qoyod($name, $unit_price);
        }

        if (!$product_id) {
            $error_output = "Product error: " . $name;
            return false;
        }

        $line_items[] = [
            "product_id"   => (int) $product_id,
            "account_id"   => $this->sales_account_code,
            "description"  => $name,
            "quantity"     => $qty,
            "unit_price"   => (string) $unit_price,
            "tax_percent"  => "15.0",
            "tax_amount"   => (string) $tax_amount,
            "is_vat_inclusive" => true
        ];
    }

    if (empty($line_items)) {
        $error_output = "No items found";
        return false;
    }

    $payload = [
    "invoice" => [
        "customer_id"  => (int) $client_id,
        "contact_id"   => (int) $client_id,

        // REMOVE THIS completely
        // "contact_name" => $customer_name,

        "inventory_id" => (int) $inventory_id,
        "issue_date"   => date('Y-m-d'),
        "due_date"     => date('Y-m-d'),
        "status"       => "Draft",
        "notes"        => "WooCommerce Order #" . $order->get_id(),
        "line_items"   => $line_items
    ]
];

    return $this->request('invoices', 'POST', $payload, $error_output)['invoice']['id'] ?? false;
}
}