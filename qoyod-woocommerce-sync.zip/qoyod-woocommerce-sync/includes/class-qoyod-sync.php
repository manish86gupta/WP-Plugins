<?php
if (!defined('ABSPATH')) exit;

class Qoyod_Sync {

    private $api;

    public function __construct() {
        $this->api = new Qoyod_API();

        add_action('woocommerce_order_status_processing', [$this, 'sync_order']);
        add_action('woocommerce_order_status_completed', [$this, 'sync_order']);

        add_filter('manage_edit-shop_order_columns', [$this, 'add_column']);
        add_action('manage_shop_order_posts_custom_column', [$this, 'render_column'], 10, 2);

        add_action('wp_ajax_qoyod_retry', [$this, 'retry_sync']);
    }

    public function sync_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        // prevent duplicate sync
        if ($order->get_meta('_qoyod_synced') == 1) return;

        $error_reason = '';

        /**
         * 1. CUSTOMER
         */
        $client_id = $this->api->create_or_update_customer($order, $error_reason);

        if (!$client_id) {
            $order->update_meta_data('_qoyod_failed', $error_reason ?: 'customer_failed');
            $order->save();
            return;
        }

        /**
         * 2. INVOICE
         */
        $invoice_id = $this->api->create_invoice_with_items($client_id, $order, $error_reason);

        if (!$invoice_id) {
            $order->update_meta_data('_qoyod_failed', $error_reason ?: 'invoice_failed');
            $order->save();
            return;
        }

        /**
         * SUCCESS
         */
        $order->update_meta_data('_qoyod_synced', 1);
        $order->delete_meta_data('_qoyod_failed');
        $order->save();
    }

    public function add_column($columns) {
        $columns['qoyod_status'] = 'Qoyod Sync';
        return $columns;
    }

    public function render_column($column, $post_id) {
        if ($column !== 'qoyod_status') return;

        $order = wc_get_order($post_id);
        if (!$order) return;

        $synced = $order->get_meta('_qoyod_synced');
        $failed = $order->get_meta('_qoyod_failed');

        if ($synced == 1) {
            echo '<span style="color:green;font-weight:bold;">✔ Synced</span>';
            return;
        }

        if (!empty($failed)) {
            echo '<div style="padding:6px;border:1px solid #f5c2c7;background:#fff1f2;border-radius:4px;">';
            echo '<div style="color:#b91c1c;font-size:11px;">✖ ' . esc_html($failed) . '</div>';
            echo '<a class="button button-small button-primary" style="margin-top:5px;" href="' .
                esc_url(admin_url('admin-ajax.php?action=qoyod_retry&order_id=' . $post_id)) .
            '">Retry Sync</a>';
            echo '</div>';
            return;
        }

        echo '<span style="color:orange;font-weight:bold;">Pending</span>';
        echo '<br>';
        echo '<a class="button button-small" href="' .
            esc_url(admin_url('admin-ajax.php?action=qoyod_retry&order_id=' . $post_id)) .
        '">Sync Now</a>';
    }

    public function retry_sync() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }

        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if (!$order_id) wp_die('Invalid order');

        $order = wc_get_order($order_id);
        if (!$order) wp_die('Order not found');

        // reset flags
        $order->delete_meta_data('_qoyod_synced');
        $order->delete_meta_data('_qoyod_failed');
        $order->save();

        // re-run sync
        $this->sync_order($order_id);

        wp_safe_redirect(wp_get_referer());
        exit;
    }
}