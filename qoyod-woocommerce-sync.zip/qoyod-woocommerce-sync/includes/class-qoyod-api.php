<?php
if (!defined('ABSPATH')) exit;

class Qoyod_API {

    private $base_url = 'https://api.qoyod.com/2.0/';

    /*
     * Qoyod account IDs
     *
     * 17 = Revenue of Products and services Sales
     * 12 = Cost of goods sold
     *
     * Change these if your Qoyod account setup is different.
     */
    private $sales_account_id   = 17;
    private $expense_account_id = 12;

    /*
     * Default Qoyod inventory.
     * Change this to the inventory/branch where WooCommerce sales
     * should be recorded.
     */
    private $inventory_id = 1;

    /**
     * Make API request
     */
    private function request($endpoint, $method = 'GET', $body = null, &$error_output = '') {

        $error_output = '';

        if (!defined('QOYOD_API_KEY') || empty(QOYOD_API_KEY)) {
            $error_output = 'Qoyod API Key missing in wp-config.php';
            return false;
        }

        $clean_endpoint = ltrim($endpoint, '/');

        $full_url = rtrim($this->base_url, '/') . '/' . $clean_endpoint;

        $args = [
            'method'  => strtoupper($method),
            'timeout' => 30,
            'headers' => [
                'API-KEY'      => QOYOD_API_KEY,
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ],
        ];

        if ($body !== null) {
            $args['body'] = wp_json_encode(
                $body,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
        }

        /*
         * Logging
         */
        error_log('QOYOD URL: ' . $full_url);
        error_log('QOYOD METHOD: ' . strtoupper($method));

        if ($body !== null) {
            error_log(
                'QOYOD REQUEST BODY: ' .
                wp_json_encode(
                    $body,
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                )
            );
        }

        $response = wp_remote_request($full_url, $args);

        if (is_wp_error($response)) {

            $error_output = $response->get_error_message();

            error_log('QOYOD WP ERROR: ' . $error_output);

            return false;
        }

        $status = wp_remote_retrieve_response_code($response);
        $raw    = wp_remote_retrieve_body($response);

        error_log('QOYOD HTTP STATUS: ' . $status);
        error_log('QOYOD RESPONSE: ' . $raw);

        $data = json_decode($raw, true);

        /*
         * HTTP error
         */
        if ($status < 200 || $status >= 300) {

            if (is_array($data) && isset($data['errors'])) {

                $error_output = $this->format_api_errors($data['errors']);

            } elseif (!empty($raw)) {

                $error_output = $raw;

            } else {

                $error_output = 'Qoyod API returned HTTP ' . $status;
            }

            return false;
        }

        /*
         * Invalid JSON
         */
        if (!empty($raw) && $data === null) {

            $error_output = 'Invalid JSON response from Qoyod API';

            return false;
        }

        return $data;
    }

    /**
     * Convert Qoyod errors array into readable text
     */
    private function format_api_errors($errors) {

        if (!is_array($errors)) {
            return (string) $errors;
        }

        $messages = [];

        foreach ($errors as $field => $field_errors) {

            if (is_array($field_errors)) {

                foreach ($field_errors as $message) {

                    $messages[] = $field . ': ' . $message;
                }

            } else {

                $messages[] = $field . ': ' . $field_errors;
            }
        }

        return implode(' | ', $messages);
    }

    /**
     * Get customer by email
     */
    public function get_customer_by_email($email) {

        if (empty($email)) {
            return false;
        }

        $error = '';

        $endpoint = 'customers?q[email_eq]=' . rawurlencode($email);

        $res = $this->request(
            $endpoint,
            'GET',
            null,
            $error
        );

        if (!$res || empty($res['customers'])) {
            return false;
        }

        return !empty($res['customers'][0]['id'])
            ? (int) $res['customers'][0]['id']
            : false;
    }

    /**
     * Get customer by name
     */
    public function get_customer_by_name($name) {

        if (empty($name)) {
            return false;
        }

        $error = '';

        $endpoint = 'customers?q[name_cont]=' . rawurlencode($name);

        $res = $this->request(
            $endpoint,
            'GET',
            null,
            $error
        );

        if (!$res || empty($res['customers'])) {
            return false;
        }

        return !empty($res['customers'][0]['id'])
            ? (int) $res['customers'][0]['id']
            : false;
    }

    /**
     * Get customer by ID
     */
    public function get_customer($customer_id) {

        $customer_id = absint($customer_id);

        if (!$customer_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'customers/' . $customer_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Create or update Qoyod customer
     */
    public function create_or_update_customer($order, &$error_output) {

        $error_output = '';

        if (!$order) {
            $error_output = 'Invalid WooCommerce order';
            return false;
        }

        /*
         * Email
         */
        $email = trim($order->get_billing_email());

        if (empty($email)) {
            $email = 'guest_' . $order->get_id() . '@local.invalid';
        }

        /*
         * Customer name
         */
        $first_name = trim($order->get_billing_first_name());
        $last_name  = trim($order->get_billing_last_name());

        $customer_name = trim(
            $first_name . ' ' . $last_name
        );

        if (empty($customer_name)) {
            $customer_name = trim($order->get_billing_company());
        }

        if (empty($customer_name)) {
            $customer_name = $email;
        }

        /*
         * Phone
         */
        $phone = trim($order->get_billing_phone());

        $phone = preg_replace(
            '/[^\d+]/',
            '',
            $phone
        );

        if (empty($phone)) {
            $phone = '0500000000';
        }

        /*
         * Addresses
         */
        $billing_address = [
            'billing_address' => trim(
                $order->get_billing_address_1() . ' ' .
                $order->get_billing_address_2()
            ),
            'billing_city'    => $order->get_billing_city(),
            'billing_state'   => $order->get_billing_state(),
            'billing_zip'     => $order->get_billing_postcode(),
            'billing_country' => $order->get_billing_country(),
        ];

        $shipping_address = [
            'shipping_address' => trim(
                $order->get_shipping_address_1() . ' ' .
                $order->get_shipping_address_2()
            ),
            'shipping_city'    => $order->get_shipping_city(),
            'shipping_state'   => $order->get_shipping_state(),
            'shipping_zip'     => $order->get_shipping_postcode(),
            'shipping_country' => $order->get_shipping_country(),
        ];

        /*
         * Qoyod Customer payload
         */
        $contact = [
            'name'         => $customer_name,
            'organization' => $order->get_billing_company(),
            'email'        => $email,
            'phone_number' => $phone,
            'status'       => 'Active',
        ];

        /*
         * Only send addresses when available.
         */
        if (
            !empty($billing_address['billing_address']) ||
            !empty($billing_address['billing_city']) ||
            !empty($billing_address['billing_country'])
        ) {
            $contact['billing_address'] = $billing_address;
        }

        if (
            !empty($shipping_address['shipping_address']) ||
            !empty($shipping_address['shipping_city']) ||
            !empty($shipping_address['shipping_country'])
        ) {
            $contact['shipping_address'] = $shipping_address;
        }

        $payload = [
            'contact' => $contact
        ];

        /*
         * First try email
         */
        $existing_id = $this->get_customer_by_email($email);

        /*
         * If email does not find customer, try name.
         */
        if (!$existing_id) {
            $existing_id = $this->get_customer_by_name(
                $customer_name
            );
        }

        /*
         * Existing customer -> update
         */
        if ($existing_id) {

            $res = $this->request(
                'customers/' . $existing_id,
                'PUT',
                $payload,
                $error_output
            );

            if ($res === false) {
                return false;
            }

            /*
             * Qoyod returns contact object.
             */
            if (
                isset($res['contact']['id']) &&
                $res['contact']['id']
            ) {
                return (int) $res['contact']['id'];
            }

            return (int) $existing_id;
        }

        /*
         * Create customer
         */
        $res = $this->request(
            'customers',
            'POST',
            $payload,
            $error_output
        );

        if ($res === false) {
            return false;
        }

        if (
            isset($res['contact']['id']) &&
            $res['contact']['id']
        ) {
            return (int) $res['contact']['id'];
        }

        $error_output = 'Customer created but Qoyod customer ID was not returned';

        return false;
    }

    /**
     * Get product by ID
     */
    public function get_product($product_id) {

        $product_id = absint($product_id);

        if (!$product_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'products/' . $product_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get product by name
     */
    public function get_product_by_name($name) {

        if (empty($name)) {
            return false;
        }

        $error = '';

        $endpoint =
            'products?q[name_en_or_name_ar_cont]=' .
            rawurlencode($name);

        $res = $this->request(
            $endpoint,
            'GET',
            null,
            $error
        );

        if (!$res || empty($res['products'])) {
            return false;
        }

        return !empty($res['products'][0]['id'])
            ? (int) $res['products'][0]['id']
            : false;
    }

    /**
     * Get product by SKU
     */
    public function get_product_by_sku($sku) {

        if (empty($sku)) {
            return false;
        }

        $error = '';

        $endpoint =
            'products?q[sku_eq]=' .
            rawurlencode($sku);

        $res = $this->request(
            $endpoint,
            'GET',
            null,
            $error
        );

        if (!$res || empty($res['products'])) {
            return false;
        }

        return !empty($res['products'][0]['id'])
            ? (int) $res['products'][0]['id']
            : false;
    }

    /**
     * Create Qoyod product
     *
     * Uses the product structure confirmed from Qoyod API.
     */
    public function create_product_in_qoyod($name, $price, $sku = '', $barcode = '') {

        $name = trim($name);

        if (empty($name)) {
            return false;
        }

        $price = round((float) $price, 2);

        if (empty($sku)) {
            $sku = 'WC-' . sanitize_title($name);
        }

        /*
         * Qoyod example uses product_unit_type_id = 6
         * which represents "piece".
         */
        $payload = [
            'product' => [
                'sku'                 => $sku,
                'barcode'             => $barcode,
                'name_ar'             => $name,
                'name_en'             => $name,
                'description'         => $name,
                'product_unit_type_id'=> 6,
                'category_id'         => 1,
                'track_quantity'      => '1',
                'purchase_item'       => '1',
                'buying_price'        => '0.0',
                'expense_account_id'  => (string) $this->expense_account_id,
                'sale_item'           => '1',
                'selling_price'       => (string) $price,
                'sales_account_id'    => (string) $this->sales_account_id,
                'tax_id'              => '1'
            ]
        ];

        /*
         * Don't send empty barcode if WooCommerce doesn't have one.
         */
        if (empty($barcode)) {
            unset($payload['product']['barcode']);
        }

        $error = '';

        $res = $this->request(
            'products',
            'POST',
            $payload,
            $error
        );

        if ($res === false) {
            return false;
        }

        if (
            isset($res['product']['id']) &&
            $res['product']['id']
        ) {
            return (int) $res['product']['id'];
        }

        return false;
    }

    /**
     * Get inventories
     */
    public function get_inventories() {

        $error = '';

        return $this->request(
            'inventories',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get inventory by ID
     */
    public function get_inventory($inventory_id) {

        $inventory_id = absint($inventory_id);

        if (!$inventory_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'inventories/' . $inventory_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get configured inventory ID
     */
    public function get_inventory_id() {

        return absint($this->inventory_id);
    }

    /**
     * Create invoice with WooCommerce order items
     */
    public function create_invoice_with_items(
        $client_id,
        $order,
        &$error_output
    ) {

        $error_output = '';

        if (!$client_id) {
            $error_output = 'Missing Qoyod customer/contact ID';
            return false;
        }

        if (!$order) {
            $error_output = 'Invalid WooCommerce order';
            return false;
        }

        /*
         * Inventory
         */
        $inventory_id = $this->get_inventory_id();

        if (!$inventory_id) {
            $error_output = 'Missing Qoyod inventory_id';
            return false;
        }

        /*
         * Dates
         */
        $issue_date = current_time('Y-m-d');

        $due_date = $issue_date;

        /*
         * WooCommerce order number
         */
        $order_number = $order->get_order_number();

        $line_items = [];

        foreach ($order->get_items() as $item_id => $item) {

            $qty = (float) $item->get_quantity();

            if ($qty <= 0) {
                continue;
            }

            $name = $item->get_name();

            /*
             * WooCommerce product
             */
            $wc_product = $item->get_product();

            $sku     = '';
            $barcode = '';

            if ($wc_product) {

                $sku = $wc_product->get_sku();

                /*
                 * WooCommerce doesn't have one universal barcode field.
                 * Try common meta keys.
                 */
                $barcode = $wc_product->get_meta('_barcode');

                if (empty($barcode)) {
                    $barcode = $wc_product->get_meta('barcode');
                }

                if (empty($barcode)) {
                    $barcode = $wc_product->get_meta('_ean');
                }
            }

            /*
             * First try SKU.
             */
            $product_id = false;

            if (!empty($sku)) {
                $product_id = $this->get_product_by_sku($sku);
            }

            /*
             * Then try product name.
             */
            if (!$product_id) {
                $product_id = $this->get_product_by_name($name);
            }

            /*
             * Create Qoyod product if missing.
             */
            if (!$product_id) {

                /*
                 * WooCommerce line total is excluding tax.
                 */
                $line_total = (float) $item->get_total();

                $unit_price = $qty > 0
                    ? round($line_total / $qty, 2)
                    : 0;

                $product_id = $this->create_product_in_qoyod(
                    $name,
                    $unit_price,
                    $sku,
                    $barcode
                );
            }

            if (!$product_id) {

                $error_output =
                    'Product error: ' . $name;

                return false;
            }

            /*
             * WooCommerce product tax.
             *
             * Prefer actual item tax rate when available.
             */
            $tax_percent = 0;

            if (function_exists('WC_Tax')) {

                $tax_rates = WC_Tax::get_rates(
                    $wc_product ? $wc_product->get_tax_class() : ''
                );

                if (!empty($tax_rates)) {

                    $first_rate = reset($tax_rates);

                    if (isset($first_rate['rate'])) {
                        $tax_percent =
                            (float) $first_rate['rate'];
                    }
                }
            }

            /*
             * Fallback to actual order tax.
             */
            if ($tax_percent <= 0) {

                $line_subtotal_tax = (float) $item->get_subtotal_tax();
                $line_subtotal     = (float) $item->get_subtotal();

                if ($line_subtotal > 0 && $line_subtotal_tax > 0) {

                    $tax_percent = round(
                        ($line_subtotal_tax / $line_subtotal) * 100,
                        2
                    );
                }
            }

            /*
             * WooCommerce line subtotal / total
             * allows us to calculate discount.
             */
            $subtotal = (float) $item->get_subtotal();
            $total    = (float) $item->get_total();

            $discount_amount = max(
                0,
                round($subtotal - $total, 2)
            );

            $discount_type = 'amount';

            /*
             * Qoyod accepts:
             * discount
             * discount_type
             * tax_percent
             */
            $line = [
                'product_id'  => (int) $product_id,
                'description' => $name,
                'quantity'    => $qty,
                'unit_price'  => $qty > 0
                    ? round($subtotal / $qty, 2)
                    : 0,
                'tax_percent' => $tax_percent
            ];

            if ($discount_amount > 0) {

                $line['discount'] =
                    $discount_amount;

                $line['discount_type'] =
                    $discount_type;
            }

            /*
             * Qoyod invoice API requires inventory information.
             */
            $line['inventory_id'] =
                (int) $inventory_id;

            $line_items[] = $line;
        }

        if (empty($line_items)) {

            $error_output =
                'No valid WooCommerce items found';

            return false;
        }

        /*
         * Invoice payload based on the supplied Qoyod
         * successful API example.
         */
        $payload = [
    'invoice' => [
        'contact_id'  => (int) $client_id,

        'reference'   =>
            'WC-' . $order_number,

        'description' =>
            'WooCommerce Order #' .
            $order_number,

        'issue_date'  => $issue_date,

        'due_date'    => $due_date,

        'status'      => 'Approved',

        'payment_method' => '1',

        'inventory_id' =>
            (int) $inventory_id,

        'line_items' =>
            $line_items
    ]
];

        /*
         * Add WooCommerce order discount if applicable.
         *
         * Qoyod order-level discount fields are only added
         * when an actual discount exists.
         */
        $order_discount =
            (float) $order->get_discount_total();

        if ($order_discount > 0) {

            $payload['invoice']['inclusive_cd_discount'] =
                round($order_discount, 2);

            $payload['invoice']['discount_account_id'] =
                (int) $this->sales_account_id;

            /*
             * The exact discount tax configuration can vary
             * by Qoyod account. Do not force a tax ID unless
             * configured.
             */
        }

        /*
         * Add notes if available.
         */
        $customer_note = trim(
            $order->get_customer_note()
        );

        if (!empty($customer_note)) {
            $payload['invoice']['notes'] =
                $customer_note;
        }

        /*
         * Create invoice
         */
        $res = $this->request(
            'invoices',
            'POST',
            $payload,
            $error_output
        );

        if ($res === false) {
            return false;
        }

        if (
            isset($res['invoice']['id']) &&
            $res['invoice']['id']
        ) {
            return (int) $res['invoice']['id'];
        }

        $error_output =
            'Invoice created but Qoyod invoice ID was not returned';

        return false;
    }

    /**
     * Get invoice by ID
     */
    public function get_invoice($invoice_id) {

        $invoice_id = absint($invoice_id);

        if (!$invoice_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'invoices/' . $invoice_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Create payment against Qoyod invoice
     *
     * Uses Qoyod invoice_payments endpoint.
     */
    public function create_invoice_payment(
        $invoice_id,
        $order,
        &$error_output
    ) {

        $error_output = '';

        $invoice_id = absint($invoice_id);

        if (!$invoice_id) {
            $error_output =
                'Missing Qoyod invoice ID';

            return false;
        }

        if (!$order) {
            $error_output =
                'Invalid WooCommerce order';

            return false;
        }

        /*
         * Account 7 = Cash on hand in supplied API example.
         *
         * If your WooCommerce payment gateway should map
         * to another Qoyod account, change this.
         */
        $account_id = 7;

        /*
         * Payment amount
         *
         * Use actual WooCommerce paid amount.
         */
        $amount = (float) $order->get_total();

        if ($amount <= 0) {
            return false;
        }

        /*
         * Payment date
         */
        $payment_date = current_time('Y-m-d');

        /*
         * Reference
         */
        $reference =
            'WC-PAY-' .
            $order->get_order_number();

        $payload = [
            'invoice_payment' => [
                'reference'  => $reference,
                'invoice_id' => (string) $invoice_id,
                'account_id' => (string) $account_id,
                'date'       => $payment_date,
                'amount'     => number_format(
                    $amount,
                    2,
                    '.',
                    ''
                )
            ]
        ];

        $res = $this->request(
            'invoice_payments',
            'POST',
            $payload,
            $error_output
        );

        if ($res === false) {
            return false;
        }

        /*
         * Qoyod invoice payment response returns id
         * at root level.
         */
        if (
            isset($res['id']) &&
            $res['id']
        ) {
            return (int) $res['id'];
        }

        $error_output =
            'Invoice payment created but Qoyod payment ID was not returned';

        return false;
    }

    /**
     * Get invoice payment
     */
    public function get_invoice_payment($payment_id) {

        $payment_id = absint($payment_id);

        if (!$payment_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'invoice_payments/' . $payment_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get accounts
     */
    public function get_accounts() {

        $error = '';

        return $this->request(
            'accounts',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get account by ID
     */
    public function get_account($account_id) {

        $account_id = absint($account_id);

        if (!$account_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'accounts/' . $account_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get categories
     */
    public function get_categories() {

        $error = '';

        return $this->request(
            'categories',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get category by ID
     */
    public function get_category($category_id) {

        $category_id = absint($category_id);

        if (!$category_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'categories/' . $category_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get product unit types
     */
    public function get_product_unit_types() {

        $error = '';

        return $this->request(
            'product_unit_types',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get product unit type
     */
    public function get_product_unit_type($unit_type_id) {

        $unit_type_id = absint($unit_type_id);

        if (!$unit_type_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'product_unit_types/' . $unit_type_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get vendors
     */
    public function get_vendors() {

        $error = '';

        return $this->request(
            'vendors',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get vendor by ID
     */
    public function get_vendor($vendor_id) {

        $vendor_id = absint($vendor_id);

        if (!$vendor_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'vendors/' . $vendor_id,
            'GET',
            null,
            $error
        );
    }

    /**
     * Get orders
     */
    public function get_orders() {

        $error = '';

        return $this->request(
            'orders',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get bills
     */
    public function get_bills() {

        $error = '';

        return $this->request(
            'bills',
            'GET',
            null,
            $error
        );
    }

    /**
     * Get invoice PDF
     */
    public function get_invoice_pdf($invoice_id) {

        $invoice_id = absint($invoice_id);

        if (!$invoice_id) {
            return false;
        }

        $error = '';

        return $this->request(
            'invoices/' . $invoice_id . '/pdf',
            'GET',
            null,
            $error
        );
    }
}