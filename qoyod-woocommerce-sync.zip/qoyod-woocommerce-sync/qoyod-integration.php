<?php
/**
 * Plugin Name: Line Apparel Qoyod WooCommerce Integration
 * Description: Sync WooCommerce orders to Qoyod (Customer + Invoice + Items)
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

/**
 * Optional safety check: ensure WooCommerce is active
 */
add_action('plugins_loaded', function () {

    if (!class_exists('WooCommerce')) {
        error_log('Qoyod: WooCommerce not active');
        return;
    }

    require_once plugin_dir_path(__FILE__) . 'includes/class-qoyod-api.php';
    require_once plugin_dir_path(__FILE__) . 'includes/class-qoyod-sync.php';

    new Qoyod_Sync();
});