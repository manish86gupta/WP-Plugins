<?php
/**
 * Plugin Name: KayanHR Jobs Integration
 * Description: FGC Fetch and display jobs from KayanHR API.
 * Version: 1.0.0
 */

if (! defined('ABSPATH')) {
	exit;
}

final class KayanHR_Jobs {

	private $api_url = 'https://developerapi.kayanhr.com/api/v1/TalentAcquisitions/GetPublishedJobPost?languageID=9';

	public function __construct() {

		add_shortcode('kayanhr_jobs', array($this, 'render_jobs_shortcode')); 
	} 

	/**
	 * Fetch jobs from API
	 */
	private function get_jobs() {

		$cache_key = 'kayanhr_jobs_cache';

		$cached = get_transient($cache_key);
		if (false !== $cached) {
			return $cached;
		}

		$headers = array(
			'Accept'       => 'application/json',
			'Content-Type' => 'application/json',
		);

		if (defined('KAYANHR_CLIENT_ID') && defined('KAYANHR_CLIENT_SECRET')) {
			$headers['clientID']     = KAYANHR_CLIENT_ID;
			$headers['clientSecret'] = KAYANHR_CLIENT_SECRET;
		}

		$response = wp_remote_get(
			$this->api_url,
			array(
				'timeout' => 20,
				'headers' => $headers,
			)
		);

		if (is_wp_error($response)) {
			error_log('KayanHR API Error: ' . $response->get_error_message());
			return array();
		}

		$status_code = wp_remote_retrieve_response_code($response);
		$body        = wp_remote_retrieve_body($response);

		/**
		 * Fallback: Basic Auth
		 */
		if ($status_code === 401 && defined('KAYANHR_CLIENT_ID')) {

			$credentials = base64_encode(
				KAYANHR_CLIENT_ID . ':' . KAYANHR_CLIENT_SECRET
			);

			$response = wp_remote_get(
				$this->api_url,
				array(
					'timeout' => 20,
					'headers' => array(
						'Accept'        => 'application/json',
						'Authorization' => 'Basic ' . $credentials,
					),
				)
			);

			$status_code = wp_remote_retrieve_response_code($response);
			$body        = wp_remote_retrieve_body($response);
		}

		if (200 !== $status_code) {
			error_log('KayanHR API HTTP Error: ' . $status_code . ' Body: ' . $body);
			return array();
		}

		$data = json_decode($body, true);

		if (
			json_last_error() !== JSON_ERROR_NONE ||
			! isset($data['Data']['lstJobPosts'])
		) {
			error_log('KayanHR Invalid Response Structure');
			return array();
		}

		$jobs = $data['Data']['lstJobPosts'];

		// Cache for 30 minutes
		set_transient($cache_key, $jobs, 30 * MINUTE_IN_SECONDS);

		return $jobs;
	}

	/**
	 * Render jobs
	 */
	public function render_jobs_shortcode() {

		$jobs = $this->get_jobs();

		ob_start();
		
		//echo '<pre>';
        //print_r($jobs);
        //echo '</pre>';

		?>

		<div class="fgc-openings-wrapper">
			
		  <?php if ( ! empty($jobs) && is_array($jobs) ) : ?>

			<?php foreach ($jobs as $job) : ?>

				<?php
				$job_title  = !empty($job['PositionName']) ? sanitize_text_field($job['PositionName']) : '';
				$Location  = !empty($job['Location']) ? sanitize_text_field($job['Location']) : '';
				$Country  = !empty($job['Country']) ? sanitize_text_field($job['Country']) : '';
				$description = !empty($job['Description']) ? wp_strip_all_tags($job['Description']) : '';
				$apply_url  = !empty($job['URL']) ? esc_url($job['URL']) : '#';
				?>

				<div class="opening-row">
					<div class="row align-items-center">

						<div class="col-md-4 col-12 mb-3 mb-md-0">
							<h3 class="job-title">
								<?php echo esc_html($job_title); ?>
							</h3>

							<span class="job-type"><?php echo $Location; ?>, <?php echo $Country; ?> </span>
						</div>

						<div class="col-md-6 col-10 mb-3 mb-md-0">
							<p class="job-desc">
								<?php
								echo !empty($description)
									? esc_html(wp_trim_words($description, 25))
									: 'No description available.';
								?>
							</p>
						</div>

						<div class="col-md-2 col-2 text-end">
							<a href="<?php echo esc_url($apply_url); ?>"
							   target="_blank"
							   class="job-arrow-btn text-white">
								<i class="bi bi-arrow-right"></i>
							</a>
						</div>

					</div>
				</div>

			<?php endforeach; ?>
			
			<?php else : ?>

				<div class="no-jobs text-center">
					<p>No open positions yet! </p>
				</div>

		   <?php endif; ?>

		</div>

		<?php

		return ob_get_clean();
	}
}

new KayanHR_Jobs();